import { Component } from '@angular/core';

@Component({
  selector: 'app-addinvoicetheme',
  templateUrl: './addinvoicetheme.component.html',
  styleUrls: ['./addinvoicetheme.component.css']
})
export class AddinvoicethemeComponent {

}
