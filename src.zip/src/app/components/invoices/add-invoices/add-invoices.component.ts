import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { AddInvoicesService } from 'src/app/services/invoices/add-invoices.service';
import { HttpHeaders } from '@angular/common/http';
import { AUTHORIZATION_TOKEN } from 'src/app/constants';
import { IInvoice, Invoice } from 'src/app/types/invoice';
@Component({
  selector: 'app-add-invoices',
  templateUrl: './add-invoices.component.html',
  styleUrls: ['./add-invoices.component.css']
})
export class AddInvoicesComponent implements OnInit {
  @ViewChild("InvoiceForm", { static: false }) InvoiceForm!: NgForm;
  Invoices!: any;
  constructor(public addInvoiceService: AddInvoicesService, public route: Router) { }

  model: any = {
    "invoice": {
      "InvoiceNo": "INV-12345"
    },
    "company": {
      "Businessname": "ABC Company",
      "address": "123 Main St",
      "GSTIN": "ABCD1234",
      "pan": "ABCDE12345",
      "postalCode": "12345",
      "emailaddress": "mailto:info@company.com",
      "website": "https://www.company.com",
      "contactNo": "123-456-7890",
      "currencyType": "USD",
      "taxType": "GST"
    },
    "billing": {
      "phone": "9876543210",
      "city": "City Name",
      "pincode": "54321",
      "apartment": "Apt 1",
      "zipcode": "12345",
      "country": "Country Name"
    },
    "shipping": {
      "phone": "9876543210",
      "city": "City Name",
      "pincode": "54321",
      "apartment": "Apt 2",
      "zipcode": "12345",
      "country": "Country Name"
    },
    "bankDetails": {
      "Bankname": "ABC Bank",
      "cardHolderName": "John Doe",
      "accountNumber": "1234567890",
      "IFSC_Code": "ABC123"
    },
    "InvoiceId": "INV-12345",
    "Email": "mailto:customer@example.com",
    "Client": "Client Name",
    "Date": "2023-06-13",
    "Billed": 100,
    "Status": "Paid"
  }



  ngOnInit(): void {

  }
  submit(f: NgForm) {
    const invoice = new Invoice();
    invoice.setData(f.value);
    const payload = invoice.getPayload();
    console.log(payload, "Payload Data");
    this.addInvoiceService.addInvoice((payload)).subscribe(
      (res: any) => {
        this.Invoices = res;
        // this.route.navigateByUrl("/invoice")
        console.log(this.Invoices, "add-form-API-Response");
      },
      (error: any) => {
        console.error(error);
      }
    );
  }
}




