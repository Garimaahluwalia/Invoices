import { UsernameDirective } from './username.directive';

describe('UsernameDirective', () => {
  it('should create an instance', () => {
    const directive = new UsernameDirective();
    expect(directive).toBeTruthy();
  });
});
