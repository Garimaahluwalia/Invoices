export enum DeleteEvents {
    CLIENTS = "CLIENTS"
}