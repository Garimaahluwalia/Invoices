export interface IInvoice {
   invoiceNo: IInvoiceClass;
   company: ICompany;
   billing: IAddress;
   shipping: IAddress;
   productDetails: IProductDetails[];
   bankDetails: IBankDetails;
   _id?: string;
   InvoiceId?: string;
   Email?: string;
   Client?: string;
   Date?: Date;
   Billed?: number;
   Status?: string;
   __v: number;
 }
 
 export interface IInvoiceClass {
   invoiceNo: string;
 }
 
 export interface ICompany {
   Businessname: string;
   address: string;
   GSTIN: string;
   pan: string;
   postalCode?: string;
   emailaddress: string;
   website?: string;
   contactNo?: string;
 }
 
 export interface IAddress {
   fullName: string;
   address: string;
   phoneNo: string;
   taxnumber: string;
   postalCode: string;
   country: string;
 }
 
 export interface IBankDetails {
   Bankname: string;
   cardHolderName: string;
   accountNumber: string;
   IFSC_Code: string;
 }
 
 export interface IProductDetails {
   tax: number;
   currency: number;
   productName: string;
   productDescription: string;
 }
 
 export class Invoice implements IInvoice {
   public invoiceNo!: IInvoiceClass;
   public company!: ICompany;
   public billing!: IAddress;
   public shipping!: IAddress;
   public productDetails!: IProductDetails[];
   public bankDetails!: IBankDetails;
   public _id?: string;
   public InvoiceId?: string;
   public Email?: string;
   public Client?: string;
   public Date?: Date;
   public Billed?: number;
   public Status?: string;
   public __v!: number;
 
   constructor() {}
 
   setInvoice({ invoiceNo }: IInvoiceClass) {
     this.invoiceNo = {
       invoiceNo: invoiceNo,
     };
   }
 
   setCompany({ Businessname, address, contactNo, emailaddress, postalCode, website, GSTIN, pan }: ICompany) {
     this.company = {
       Businessname: Businessname,
       address: address,
       GSTIN: GSTIN,
       pan: pan,
       contactNo: contactNo,
       emailaddress: emailaddress,
       postalCode: postalCode,
       website: website,
     };
   }
 
   setBilling(address: IAddress) {
     this.billing = address;
   }
 
   setShipping(address: IAddress) {
     this.shipping = address;
   }
 
   setProductDetails(productDetails: IProductDetails[]) {
     this.productDetails = productDetails;
   }
 
   setBankDetails({ Bankname, cardHolderName, accountNumber, IFSC_Code }: IBankDetails) {
     this.bankDetails = {
       Bankname: Bankname,
       cardHolderName: cardHolderName,
       accountNumber: accountNumber,
       IFSC_Code: IFSC_Code,
     };
   }
 
   setData(values: { [key: string]: string | number | { [key: string]: string | number } }) {
     this.setInvoice(values["invoice"] as unknown as IInvoiceClass);
     this.setCompany(values["company"] as unknown as ICompany);
     this.setBilling(values["billing"] as unknown as IAddress);
     this.setShipping(values["shipping"] as unknown as IAddress);
     this.setProductDetails(values["productDetails"] as unknown as IProductDetails[]);
     this.setBankDetails(values["bankDetails"] as unknown as IBankDetails);
   }
 
   getPayload() {
     return {
       invoice: this.invoiceNo,
       company: this.company,
       billing: this.billing,
       shipping: this.shipping,
       productDetails: this.productDetails,
       bankDetails: this.bankDetails,
     };
   }
 }
 