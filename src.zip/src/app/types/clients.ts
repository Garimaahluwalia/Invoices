export interface IClients{
    name : string,
    email : string,
    phoneNumber : string,
    registeredNo : string
}