export interface ISignUp{
    username:string,
    email: string,
    password: string
}