export interface IClients{
    name : string,
    email : string,
    phoneNumber : string,
    address: string,
    registeredNo : string
}