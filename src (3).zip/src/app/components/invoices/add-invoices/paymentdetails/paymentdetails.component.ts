import { Component, OnInit } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';
import { ClientService } from 'src/app/services/clients/client.service';
import { AddInvoicesService } from 'src/app/services/invoices/add-invoices.service';
import { IbankDetails } from 'src/app/types/invoice';
import { numberToWords } from "src/app/common/numberToWords";

@Component({
  selector: 'app-paymentdetails',
  templateUrl: './paymentdetails.component.html',
  styleUrls: ['./paymentdetails.component.css'],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]

})
export class PaymentdetailsComponent implements OnInit {
  public amount: any;
  public tax: any;
  public rate: any;
  public total: any;
  public currency: any;
  public taxAmountData: any;
  public totalAmount: any;
  public totalrate: any;
  public productRows: any[] = [];
  public totalTotalAmount: any;
  public AmountInWords: any;
  public totalAmountInWords!: string;
  public totalOfAllItemsFromProduct : any;
  public totalOfAmountFromProduct: any;

  constructor(public clientService: ClientService, public addinvoiceService: AddInvoicesService) { }
  ngOnInit(): void {

    this.addinvoiceService.recieveProductRows().subscribe((res: any[]) => {
      this.productRows = res;
      console.log(this.productRows, "ProductRows[[[[[[[[[[[[[[[[[[[[[[[[[[")
      if (res.length > 0) {
        const firstElement = res[0];
        this.amount = firstElement.amount;
        this.tax = firstElement.tax;
        this.rate = firstElement.rate;
        this.total = firstElement.total;
        
        console.log(this.totalOfAllItemsFromProduct, "TOTAL FROM PRODUCTS")
        if (this.productRows.length > 0) {
          this.totalOfAllItemsFromProduct= this.productRows.reduce((acc, row) => acc + parseFloat(row.total), 0).toFixed(2);
         this.totalOfAmountFromProduct = this.productRows.reduce((acc, row) => acc + row.amount, 0);
          this.totalrate = parseFloat(this.productRows.reduce((total: any, row: { rate: any }) => total + parseFloat(row.rate), 0)).toFixed(2);
          this.totalAmountInWords = parseFloat(this.totalTotalAmount) ? numberToWords(this.totalTotalAmount) : (parseFloat(this.totalAmount) ? numberToWords(this.totalAmount) : "");
          console.log(this.totalAmountInWords, "AmountInWords")
          if (isNaN(this.totalAmount)) {
            this.totalAmount = "0.00";
          }
          if (isNaN(this.totalrate)) {
            this.totalrate = "0.00";
          }
          if (isNaN(this.totalTotalAmount)) {
            this.totalTotalAmount = "0.00";
          }
        } else {
          this.totalAmount = 0;
          this.totalTotalAmount = 0;
        }
      }
    });

    this.addinvoiceService.receiveCurrency().subscribe((res: any) => {
      this.currency = res;
    });

    if (!this.currency || this.currency === '') {
      this.currency = '$';
    }

    this.clientService.recieveTaxName().subscribe((res: any) => {
      this.tax = res;

    });

    this.addinvoiceService.receiveCurrency().subscribe((res: any) => {
      this.currency = res;

    });
  }


  public Bankdetails: IbankDetails = {
    "accountHolderName": "M CODE INFOSOFT",
    "accountNumber": "098878776809454",
    "ifscCode": "ICICINBBCTS",
    "swiftCode": "9898BHBZA23",
    "bank": "ICICI Bank Ltd.",
  };

}
