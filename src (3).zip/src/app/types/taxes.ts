export enum TAXES {
    NONE = "NONE",
    GST = "GST",
    IGST = "IGST",
    CGST_OR_SGST = "CGST_SGST",
    VAT = "VAT",
    PPN = "PPN",
    SST = "SST",
    HST = "HST",
    TAX = "TAX"
}


