export enum DeleteEvents {
    INVOICES=  "INVOICES",
    CLIENTS = "CLIENTS"
}